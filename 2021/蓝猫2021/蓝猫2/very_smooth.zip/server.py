#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import string
import random
import socketserver
import signal
import codecs
from os import urandom
from hashlib import sha256
from Crypto.Util.number import bytes_to_long
from Crypto.PublicKey import RSA
from flag import FLAG


BANNER = rb"""
 __   __              ___                _   _    
 \ \ / /__ _ _ _  _  / __|_ __  ___  ___| |_| |_  
  \ V / -_) '_| || | \__ \ '  \/ _ \/ _ \  _| ' \ 
   \_/\___|_|  \_, | |___/_|_|_\___/\___/\__|_||_|
               |__/                                  
"""

MENU = rb"""
[1] Encrypt
[2] Get Public Key
[3] Hint
[4] Exit
"""

with open('public.key', 'rb') as f:
    public_key_bytes = f.read()
public_key = RSA.import_key(public_key_bytes)
N = public_key.n
E = public_key.e


class Task(socketserver.BaseRequestHandler):
    def _recvall(self):
        BUFF_SIZE = 2048
        data = b''
        while True:
            part = self.request.recv(BUFF_SIZE)
            data += part
            if len(part) < BUFF_SIZE:
                break
        return data.strip()

    def send(self, msg, newline=True):
        try:
            if newline:
                msg += b'\n'
            self.request.sendall(msg)
        except:
            pass

    def recv(self, prompt=b'> '):
        self.send(prompt, newline=False)
        return self._recvall()

    def proof_of_work(self):
        random.seed(urandom(128))
        alphabet = string.ascii_letters + string.digits
        proof = ''.join(random.choices(alphabet, k=16))
        hash_value = sha256(proof.encode('ascii')).hexdigest()
        self.send(('sha256(XXXX+%s) == %s' % (proof[4:], hash_value)).encode('ascii'))
        nonce = self.recv(prompt=b'Give me XXXX > ')
        if len(nonce) != 4 or sha256(nonce + proof[4:].encode('ascii')).hexdigest() != hash_value:
            return False
        return True

    def timeout_handler(self, signum, frame):
        self.send(b'\nTimeout!')
        raise TimeoutError

    def handle(self):
        signal.signal(signal.SIGALRM, self.timeout_handler)
        signal.alarm(60)
        
        if not self.proof_of_work():
            self.send(b'\nWrong!')
            self.request.close()
            return

        self.send(BANNER)

        signal.alarm(60)

        while True:
            self.send(MENU, newline=False)
            try:
                choice = int(self.recv(prompt=b'Enter option > '))
            except:
                self.send(b'Error!')
                break

            # Encrypt
            if choice == 1:
                try:
                    m = codecs.decode(self.recv(prompt=b'Enter your plaintext in hex > '), 'hex')
                except:
                    self.send(b'Error!')
                    break
                m = bytes_to_long(m)
                c = hex(pow(m, E, N))[2:]
                self.send(b'Here is your ciphertext in hex: ')
                self.send(c.encode('ascii'))

            # Get Public Key
            elif choice == 2:
                fake_n = int('f' * 1030, 16)
                rsa = RSA.construct((fake_n, E))
                fake_public_key = rsa.exportKey()
                self.send(b'\n' + fake_public_key + b'\n')
                self.send(b'Damn it! Our public key was modified by hackers! And they left us a message: ')
                encrypted_flag = pow(bytes_to_long(FLAG.encode('ascii')), E, N)
                self.send(hex(encrypted_flag)[2:].encode('ascii'))

            # Hint
            elif choice == 3:
                with open('init_public_key.py', 'rb') as f:
                    self.send(b'\n' + f.read())

            # Exit
            elif choice == 4:
                break

            else:
                self.send(b'Error!')
                break

        self.send(b'Bye!\n')
        self.request.close()


class ForkedServer(socketserver.ForkingMixIn, socketserver.TCPServer):
    pass


if __name__ == "__main__":
    HOST, PORT = '0.0.0.0', 30000
    print(HOST, PORT)
    server = ForkedServer((HOST, PORT), Task)
    server.allow_reuse_address = True
    server.serve_forever()
