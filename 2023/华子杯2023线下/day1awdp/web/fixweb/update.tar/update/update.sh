#!/bin/sh
chmod 777 login.php; mv -f login.php /var/www/html/login.php
