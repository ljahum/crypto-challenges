根据题目triple猜测应该是TrilpeDES加密，然后纸条是密钥，所以直接在线解密

http://www.jsons.cn/tripledesencrypt/

![1](C:\Users\16953\Desktop\代打\题目.txt\1.png)

